package com.webapp.springmvc.dao;

import java.util.List;

import com.webapp.springmvc.model.StationInfoPOJO;

public interface StationInfoDAO 
{	
	StationInfoPOJO findById(int id);
	 
    void saveStation(StationInfoPOJO stationObj);
     
    void deleteStationBySysId(String ssn);
     
    List<StationInfoPOJO> findAllStations();
 
    StationInfoPOJO findStationBySysId(String sysId);
}