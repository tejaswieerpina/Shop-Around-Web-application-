package com.webapp.springmvc.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.webapp.springmvc.dao.LocationInfoDAO;
import com.webapp.springmvc.model.LocationInfoPOJO;


@Service("locationService")
@Transactional
public class LocationInfoServiceImpl implements LocationInfoService {

	@Autowired
	LocationInfoDAO dao;
	
	@Override
	public LocationInfoPOJO findById(int id) {
		return dao.findById(id);
	}

	@Override
	public void saveLocation(LocationInfoPOJO locationObj) {
		dao.saveLocationInfo(locationObj);
	}

	@Override
	public List<LocationInfoPOJO> findAllLocations() {
		return dao.findAllLocations();
	}

	@Override
	public List<LocationInfoPOJO> findByIpAddress(String ipAddress) {
		return dao.findByIpAddress(ipAddress);
	}

	@Override
	public List<LocationInfoPOJO> findByOfficeId(String officeId) {
		return dao.findByOfficeId(officeId);
	}

	@Override
	public void updateLocation(LocationInfoPOJO locationObj) {
		dao.updateLocationInfo(locationObj);		
	}

	@Override
	public void deleteLocationInfo(LocationInfoPOJO locationObj) {
		dao.deleteLocationInfo(locationObj);
		
	}

}
