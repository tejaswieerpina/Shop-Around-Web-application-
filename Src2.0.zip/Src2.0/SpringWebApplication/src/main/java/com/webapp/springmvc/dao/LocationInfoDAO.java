package com.webapp.springmvc.dao;

import java.util.List;

import com.webapp.springmvc.model.LocationInfoPOJO;

public interface LocationInfoDAO {
	
	LocationInfoPOJO findById(int id);
	 
    void saveLocationInfo(LocationInfoPOJO locationObj);
    
    void updateLocationInfo(LocationInfoPOJO locationObj);
    
    void deleteLocationInfo(LocationInfoPOJO locationObj);
    
    List<LocationInfoPOJO> findAllLocations();

    List<LocationInfoPOJO> findByIpAddress(String ipAddress);
    
    List<LocationInfoPOJO> findByOfficeId(String officeId); 
}
