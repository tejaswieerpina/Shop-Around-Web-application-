package com.webapp.springmvc.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.google.gson.Gson;
import com.webapp.springmvc.model.LocationInfoPOJO;
import com.webapp.springmvc.model.StationInfoPOJO;
import com.webapp.springmvc.service.LocationInfoService;
import com.webapp.springmvc.service.StationInfoService;

@Controller
@RequestMapping("/location-module")
public class LocationController {
	
	@Autowired
	LocationInfoService service;
	
	@Autowired
	StationInfoService service1;
	
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String setupForm(Model model) {
		LocationInfoPOJO locationObj = new LocationInfoPOJO();
		model.addAttribute("location", locationObj);
		List<LocationInfoPOJO> locations = service.findAllLocations();
		model.addAttribute("locations", locations);
		return "location";
	}
	
	@RequestMapping(value = "/update", method = RequestMethod.GET)
	public String setupForm(@RequestParam("id") int id, Model model) {
		LocationInfoPOJO locationObj = service.findById(id);
		if(locationObj==null)
			locationObj = new LocationInfoPOJO();
		model.addAttribute("location", locationObj);
		List<StationInfoPOJO> staions = service1.getAllStations();
		List<Integer> stationSysIds = new ArrayList<Integer>();
		for (StationInfoPOJO s : staions){
			if(s!=null)
				stationSysIds.add(s.getSysId());
		}
		model.addAttribute("allStaionSysIds", staions);
		return "updateLocation"; 
	}
	
	@RequestMapping(value = "/search", method = RequestMethod.GET)
	public String submitForm(@ModelAttribute("location") LocationInfoPOJO locationObj,
			BindingResult result, SessionStatus status,
	        final Model model, 
	        final RedirectAttributes redirectAttributes) {
		//model location object to bind with form
		model.addAttribute("location", locationObj);
		System.out.println(locationObj);
		
		//add searched result locaiton list to show in table
		if( !StringUtils.isEmpty(locationObj.getIpAddress())){
			System.out.println("searching for location with IP Add  "+locationObj.getIpAddress());
			List<LocationInfoPOJO> location1 = service.findByIpAddress(locationObj.getIpAddress());
			model.addAttribute("listLocation", location1);
		}else if(locationObj.getStation()!=null && !StringUtils.isEmpty(locationObj.getStation().getStationId())){
			//List<LocationInfoPOJO> location1 = service.findByIpAddress(locationObj.getStation().getStationId());
			List<LocationInfoPOJO> location1 = new ArrayList<LocationInfoPOJO>();
			model.addAttribute("listLocation", location1);
		}else if(!StringUtils.isEmpty(locationObj.getOfficeId())){
			System.out.println("searching for location with office Id "+locationObj.getOfficeId());
			List<LocationInfoPOJO> location1 = service.findByOfficeId(locationObj.getOfficeId());
			System.out.println("result===>"+location1);
			model.addAttribute("listLocation", location1);
		}else{
			List<LocationInfoPOJO> location1 = new ArrayList<LocationInfoPOJO>();
			model.addAttribute("listLocation", location1);
		}
		
		//add all location list to set in drop down
		List<LocationInfoPOJO> locations = service.findAllLocations();
		model.addAttribute("locations", locations);
		
		// Mark Session Complete
		status.setComplete();
		return "location";
	}
	
	
	@RequestMapping(value = "/addNew", method = RequestMethod.GET)
	public String addNewForm(Model model) {
		LocationInfoPOJO locationObj = new LocationInfoPOJO();
		model.addAttribute("location", locationObj);
		List<StationInfoPOJO> staions = service1.getAllStations();
		model.addAttribute("allStaionSysIds", staions);
		List<LocationInfoPOJO> locations = service.findAllLocations();
		List<String> locationMap = new ArrayList<String>();
		for(LocationInfoPOJO loc : locations){
			locationMap.add(loc.getOfficeId()+"#"+ loc.getL1ServerCd());
		}
		model.addAttribute("locationMap", new Gson().toJson(locationMap));
		
		model.addAttribute("locations", locations);
		return "addLocationInfo";
	}
	
	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public String saveForm(@ModelAttribute("location") LocationInfoPOJO locationObj,
			BindingResult result, SessionStatus status,
	        final Model model, 
	        final RedirectAttributes redirectAttributes) {
		StationInfoPOJO stationObj = service1.findById(locationObj.getStation().getSysId());
		locationObj.setStation(stationObj);
		service.saveLocation(locationObj);
		
		redirectAttributes.addFlashAttribute("location1", locationObj);
		// Mark Session Complete
		status.setComplete();
		return "redirect:success";
	}
	
	@RequestMapping(value = "/success", method = RequestMethod.GET)
	public String success(Model model, @ModelAttribute("location1") LocationInfoPOJO loctionObj) {
		model.addAttribute("location", loctionObj);
		return "addSuccess";
	}
	
	@RequestMapping(value = "/update", method = RequestMethod.POST)
	public String updateForm(@ModelAttribute("location") LocationInfoPOJO locationObj,
			BindingResult result, SessionStatus status,
	        final Model model, 
	        final RedirectAttributes redirectAttributes) {
		
		StationInfoPOJO stationObj = service1.findById(locationObj.getStation().getSysId());
		locationObj.setStation(stationObj);
		service.updateLocation(locationObj);
		
		redirectAttributes.addFlashAttribute("location1", locationObj);
		// Mark Session Complete
		status.setComplete();
		return "redirect:updateSuccess";
	}
	
	@RequestMapping(value = "/updateSuccess", method = RequestMethod.GET)
	public String updateSuccess(Model model, @ModelAttribute("location1") LocationInfoPOJO loctionObj) {
		model.addAttribute("location", loctionObj);
		return "updateSuccess";
	}
	
	@RequestMapping(value = "/delete", method = RequestMethod.GET)
	public String deleteForm(@RequestParam("id") int id, Model model) {
		LocationInfoPOJO locationObj = service.findById(id);
		if(locationObj!=null)
			service.deleteLocationInfo(locationObj);
		model.addAttribute("location", locationObj);
		return "deleteSuccess"; 
	}
	
	@RequestMapping(value = "/deleteSuccess", method = RequestMethod.GET)
	public String deleteSuccess(Model model, @ModelAttribute("location1") LocationInfoPOJO loctionObj) {
		model.addAttribute("location", loctionObj);
		return "deleteSuccess";
	}
	

	
}
