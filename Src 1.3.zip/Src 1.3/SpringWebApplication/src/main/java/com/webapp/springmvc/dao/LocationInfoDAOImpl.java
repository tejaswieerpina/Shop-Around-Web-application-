package com.webapp.springmvc.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import com.webapp.springmvc.model.LocationInfoPOJO;
import com.webapp.springmvc.model.StationInfoPOJO;

@Repository
public class LocationInfoDAOImpl  extends AbstractDAO<Integer, LocationInfoPOJO> implements LocationInfoDAO{

	@Override
	public LocationInfoPOJO findById(int id) {
		return getByKey(id);
	}

	@Override
	public void saveLocationInfo(LocationInfoPOJO locationObj) {
		persist(locationObj);
		
	}

	@Override
	public List<LocationInfoPOJO> findAllLocations() {
		Criteria criteria = createEntityCriteria();
        return (List<LocationInfoPOJO>) criteria.list();
	}

	@Override
	public List<LocationInfoPOJO> findByIpAddress(String ipAddress) {
		Criteria criteria = createEntityCriteria();
        criteria.add(Restrictions.eq("ipAddress", ipAddress));
        return (List<LocationInfoPOJO>) criteria.list();
	}
	
	@Override
	public List<LocationInfoPOJO> findByOfficeId(String officeId) {
		Criteria criteria = createEntityCriteria();
        criteria.add(Restrictions.eq("officeId", officeId));
        return (List<LocationInfoPOJO>) criteria.list();
	}

}
