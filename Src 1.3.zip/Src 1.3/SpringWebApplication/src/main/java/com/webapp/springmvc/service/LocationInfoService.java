package com.webapp.springmvc.service;

import java.util.List;

import com.webapp.springmvc.model.LocationInfoPOJO;

public interface LocationInfoService {
	
	LocationInfoPOJO findById(int id);
	
	List<LocationInfoPOJO> findByIpAddress(String ipAddress);
	
	void saveLocation(LocationInfoPOJO locationObj);
	
	List<LocationInfoPOJO> findAllLocations();
	
	List<LocationInfoPOJO> findByOfficeId(String officeId);

}
