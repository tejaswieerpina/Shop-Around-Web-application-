package com.webapp.springmvc.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;
import com.webapp.springmvc.model.StationInfoPOJO;

@Repository
public class StationInfoDAOImpl extends AbstractDAO<Integer, StationInfoPOJO>  implements StationInfoDAO {

	@Override
	public StationInfoPOJO findById(int id) {
		return getByKey(id);
	}

	@Override
	public void saveStation(StationInfoPOJO stationObj) {
		persist(stationObj);
		
	}

	@Override
	public void deleteStationBySysId(String sysId) {
		Query query = getSession().createSQLQuery("delete from StationInfoPOJO where sysId = :sysId");
        query.setString("sysId", sysId);
        query.executeUpdate();
		
	}

	@Override
	public List<StationInfoPOJO> findAllStations() {
		Criteria criteria = createEntityCriteria();
        return (List<StationInfoPOJO>) criteria.list();
	}

	@Override
	public StationInfoPOJO findStationBySysId(String sysId) {
		Criteria criteria = createEntityCriteria();
        criteria.add(Restrictions.eq("sysId", sysId));
        return (StationInfoPOJO) criteria.uniqueResult();
	}
}